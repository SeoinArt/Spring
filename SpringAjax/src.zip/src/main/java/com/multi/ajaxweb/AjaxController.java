package com.multi.ajaxweb;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AjaxController {
	
	@GetMapping("/ajaxView")
	public String ajaxView() {
		return "ajax/ajaxView";
	}
}
