package com.my.myapp;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.shop.model.CategoryVO;
import com.shop.model.ProductVO;
import com.shop.service.AdminService;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/admin")
@Log4j
public class AdminController {
	
	@Inject
	private AdminService adminService;
	
	@GetMapping("/prodForm")
	public String productForm(Model m) {
		
		//���� ī�װ��� ��� ��������
		List<CategoryVO> upCgList=adminService.getUpcategory();
		m.addAttribute("upCgList",upCgList);
		
		
		return "admin/prodInput";
		//WEB-INF/views/admin/prodInput.jsp
	}
	@PostMapping("/prodInput")
	public String productInsert(Model m, @ModelAttribute ProductVO item, 
				@RequestParam("pimage") List<MultipartFile> pimage, 
				HttpServletRequest req) {
		//1. ���ε� ���丮 ������ ���  "/resources/product_images"
		ServletContext app=req.getServletContext();
		String upDir=app.getRealPath("/resources/product_images");
		log.info("upDir: "+upDir);
		
		//2. ���ε� ó�� =>�ݺ� ���鼭 transferTo(), ���ε� ���ϸ��� item�� setting�Ѵ�. item.setPimage1(), item.setPimage2()...
		if(pimage!=null) {
			for(int i=0;i<pimage.size();i++) {
				MultipartFile mf=pimage.get(i);
				if(!mf.isEmpty()) {//÷�������� �ִٸ�
					try {
						SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhmmss");
						String str=sdf.format(new Date());
						String fname=str+"_"+mf.getOriginalFilename();
						mf.transferTo(new File(upDir,fname));
						if(i==0) {
							item.setPimage1(fname);
						}else if(i==1) {
							item.setPimage2(fname);
						}else if(i==2) {
							item.setPimage3(fname);
						}
						
					}catch(IOException e) {
						log.error("���� ���ε� ����: "+e);
					}
				}//if---
			}//for----
		}//if------------------------
		 
		
		log.info("item=="+item);
		int n=adminService.productInsert(item);//DB�� insert�� ����
		String str=(n>0)?"��� ����":"��� ����";
		String loc=(n>0)?"prodList":"javascript:history.back()";
		m.addAttribute("msg",str);
		m.addAttribute("loc",loc);
		return "message";
	}//--------------------------------------
	
	@GetMapping("/prodList")
	public String productList(Model m) {
		
		List<ProductVO> prodArr=adminService.productList();
		
		m.addAttribute("itemList", prodArr);
		return "admin/prodList";
	}
	

}



