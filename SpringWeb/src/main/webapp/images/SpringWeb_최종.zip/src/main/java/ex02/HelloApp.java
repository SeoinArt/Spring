package ex02;

public class HelloApp {

	public static void main(String[] args) {
		
		MessageBean mb=new MessageBeanKo(); //new MessageBeanEn();
		mb.sayHello("Scott");
	}

}
