package com.my.myapp;


import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shop.model.ProductVO;
import com.shop.service.ShopService;

@Controller
public class IndexController {
	
	@Inject
	private ShopService shopService;
	
	//������� ��ȯ���� ������(void)
		//@RequestMapping("/index") �� ����� "/index" => ������� �ȴ�
		@RequestMapping("/index")
		public void showIndex(Model m) {
			
			List<ProductVO> pList=shopService.selectByPspec("HIT");
			
			List<ProductVO> pList2=shopService.selectByPspec("NEW");
			
			m.addAttribute("pspec","HIT");
			m.addAttribute("pspec2","NEW");
			
			m.addAttribute("pList",pList);
			m.addAttribute("pList2",pList2);
			//WEB-INF/views/index.jsp
		}
	

}
