package ex01;

public class MessageBeanEn {
	
	public void sayHello(String name) {
		System.out.println("Hello "+name+"~~~");
	}

}
