package com.shop.model;

public class CategoryVO {

}
