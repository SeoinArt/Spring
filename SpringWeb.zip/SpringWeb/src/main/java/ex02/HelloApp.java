package ex02;

public class HelloApp {

	public static void main(String[] args) {
//		MessageBean mb = new MessageBeanEn();
		MessageBean mb = new MessageBeanKo();
		mb.sayHello("scott");
	}

}
